music={
    "stealth": "https://www.youtube.com/watch?v=U47Tr9BB_wE&list=RDU47Tr9BB_wE&start_radio=1",
    "ap": "https://www.youtube.com/watch?v=slM5s55Jz0k&list=RDslM5s55Jz0k&start_radio=1"
}